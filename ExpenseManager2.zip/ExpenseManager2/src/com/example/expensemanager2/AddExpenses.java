package com.example.expensemanager2;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.app.ActionBar;
import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
public class AddExpenses extends Activity   {
	private Calendar cal;
	private int day;
	private int month;
	private int year;
	ActionBar actionbar;
	TextView tv,tv1,tv_expenses;
	SQLiteDatabase db;
	String in_exp;
	EditText ed_add_expense_amt,ed_add_expense_description;
	List<String> stringlist;
	//time picker
	
	String spdescription,s1;
	Spinner sp_add_expenses_category;
	Button b1,btn_ex_cur_time,btn_ex_cur_date;
	android.widget.RelativeLayout.LayoutParams layoutparams;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_expenses);
		ActionBarTitleGravity();
		
		ed_add_expense_amt=(EditText)findViewById(R.id.ed_add_expense_amt);
		ed_add_expense_description=(EditText)findViewById(R.id.ed_add_expense_description);
		 getActionBar().setHomeButtonEnabled(true);
		 getActionBar().setDisplayHomeAsUpEnabled(true);
		 btn_ex_cur_time=(Button)findViewById(R.id.btn_ex_cur_time);
		 btn_ex_cur_date=(Button)findViewById(R.id.btn_ex_cur_date);
		 tv1=(TextView)findViewById(R.id.textView1);
		 timedateonbtn();
		// ADD SPINNER
		 	sp_add_expenses_category=(Spinner)findViewById(R.id.sp_add_expense_category);
		 	ArrayAdapter<CharSequence> ad=ArrayAdapter.createFromResource(this,R.array.sp_add_expenses_category,android.R.layout.simple_spinner_dropdown_item);
			ad.setDropDownViewResource(android.R.layout.simple_spinner_item);
			sp_add_expenses_category.setAdapter(ad);
			sp_add_expenses_category.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> parent, View arg1,
						int pos, long arg3)
				{
					spdescription=(String)parent.getItemAtPosition(pos);
					
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0)
				{
					// TODO Auto-generated method stub
					
				}
			});	

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.add_expenses, menu);
		return true;
	}
	
	
	
	
		//create alertbox
	  	public void addcategory(View v)
	  	{
		  AlertDialog.Builder	dialogbuilder =  new AlertDialog.Builder(this);
		  LayoutInflater inflater=this.getLayoutInflater();
		  final View dialogview=inflater.inflate(R.layout.activity_alert_box2, null);
		  dialogbuilder.setView(dialogview);
		  dialogbuilder.setTitle("Expense categories");
		 final EditText ed1=(EditText)dialogview.findViewById(R.id.newed);
		  List<String> planets = new ArrayList<String>(Arrays.asList(getResources().getStringArray(R.array.sp_add_expenses_category)));
		  final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,planets);
		  sp_add_expenses_category.setAdapter(adapter);
		  Button b1=(Button)dialogview.findViewById(R.id.newcategory);
		 
		  final AlertDialog b = dialogbuilder.create();
		  b.show();
		  b1.setOnClickListener(new OnClickListener() 
		  {
			
			@Override
			public void onClick(View arg0)
			{
			String textholder = "" + ed1.getText().toString();
			adapter.add(textholder);
			b.dismiss();
				Toast.makeText(getApplicationContext(), "New Category Successfully Inserted", Toast.LENGTH_LONG).show();
			}
		});
	  }
	  	@Override
		public boolean onOptionsItemSelected(MenuItem item)
		{
			switch (item.getItemId())
			{
					case android.R.id.home:
						this.finish();
						Intent i = new Intent(this,Homepage.class);
						startActivity(i);
						
						break;

			default:
				return super.onOptionsItemSelected(item);
			}
			return true;
			
		}

	  	
	  	private void ActionBarTitleGravity() 
	    {
	    	
		actionbar = getActionBar();
		actionbar.setHomeButtonEnabled(true);
		  actionbar.setDisplayHomeAsUpEnabled(true);
		  actionbar.setIcon(getResources().getDrawable(R.drawable.unnamed));
		actionbar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#37b2eb")));
		//for textview in action bar
		tv=new TextView(getApplicationContext());
		layoutparams=new RelativeLayout.LayoutParams(layoutparams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);
		tv.setLayoutParams(layoutparams);
		tv.setText("Add Expense");
		tv.setTextColor(Color.parseColor("#FFFFFF"));
		tv.setGravity(Gravity.CENTER);
		tv.setTextSize(20);
		actionbar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM | ActionBar.DISPLAY_SHOW_HOME);
		
		actionbar.setCustomView(tv);
		//for button in action bar

}
	  	
	  	private void timedateonbtn()
	  	{
	  		Calendar cal=Calendar.getInstance();
	  		// time
	  		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm");
	  		String sdftime = sdf.format(cal.getTime());
	  		btn_ex_cur_time.setText(sdftime);
	  		//date
	  		String date = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
	  		btn_ex_cur_date.setText(date);
	  	}
	  	public void btn_showdate_click(View v)
		{
			 cal=Calendar.getInstance();
			 year=cal.get(Calendar.YEAR);
			 month=cal.get(Calendar.MONTH);
			 day=cal.get(Calendar.DAY_OF_MONTH);
			 showDialog(0);
		}
		protected Dialog onCreateDialog(int id)
		{
			return new DatePickerDialog(this,datepickerlitener,year,month,day);
					
		}
		private DatePickerDialog.OnDateSetListener datepickerlitener = new DatePickerDialog.OnDateSetListener()
		{
			
			@Override
			public void onDateSet(DatePicker view, int selectedday, int selectedmonth, int selectedyear)
			{
			
			btn_ex_cur_date.setText(selectedday + " / " + (selectedmonth+1) + "/" +selectedyear);	
			}
		};
		public void showtime(View v)
		{
		Toast.makeText(this, "hello",Toast.LENGTH_LONG).show();	
		}
		public void btnsave(View v) 
		{
			if(ed_add_expense_amt.getText().toString().equals(""))
			{
				ed_add_expense_amt.setError("Enter Amount");
			}
			else if(ed_add_expense_description.getText().toString().equals(""))
			{
				ed_add_expense_description.setError("Enter Description");
				ed_add_expense_description.hasFocus();
				
			}
			else
			{
			db=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.CREATE_IF_NECESSARY,null);
			String createtable = "create table if not exists expenses(ex_id integer primary key autoincrement,ex_amount decimal,ex_type text,ex_date text,ex_time text,ex_description text)";
			db.setLocale(Locale.getDefault());
			db.execSQL(createtable);
			String sql="insert into expenses(ex_amount,ex_type,ex_date,ex_time,ex_description)values('"+ed_add_expense_amt.getText().toString()+"','"+spdescription+"','"+btn_ex_cur_date.getText().toString()+"','"+btn_ex_cur_time.getText().toString()+"','"+ed_add_expense_description.getText().toString()+"')";
			db.setLocale(Locale.getDefault());
			db.execSQL(sql);
			Toast.makeText(this, "Expense Succesfully Inserted", Toast.LENGTH_LONG).show();
			
			SQLiteDatabase db2=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE,null);
			Cursor c2=db2.rawQuery("select sum(ex_amount) from expenses", null);
			if(c2.moveToNext())
			{
				in_exp=c2.getString(0).toString();
				//tv_expenses.setText(in_exp);	
				c2.close();
			}
			
			
			
			
			
			new AlertDialog.Builder(this)
			.setMessage(in_exp)
			.setTitle("Your Total Expense Is")
			
			.setPositiveButton("OK",new DialogInterface.OnClickListener()
			{
				
				@Override
				public void onClick(DialogInterface arg0, int arg1) 
				{
					// TODO Auto-generated method stub
					
				}
			}).show();
			
			}
			
			
			
					
						
			
		}
		
		
}
		 
	
