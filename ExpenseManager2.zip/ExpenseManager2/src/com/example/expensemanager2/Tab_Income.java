package com.example.expensemanager2;



import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class Tab_Income extends Activity 
{
	Spinner sp_add_income_category;
	String s;
	private Calendar cal;
	private int day,month,year;
	
	Button btn_tab_in_date,btn_tab_in_time;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tab__income);
		addspinner();
		
		btn_tab_in_date=(Button)findViewById(R.id.btn_tab_in_date);
		btn_tab_in_time=(Button)findViewById(R.id.btn_tab_in_time);
		 timedateonbtn();
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.tab__income, menu);
		return true;
	}
	public void addincomecategory(View v)
	  {
		  AlertDialog.Builder	dialogbuilder =  new AlertDialog.Builder(this);
		  LayoutInflater inflater=this.getLayoutInflater();
		  final View dialogview=inflater.inflate(R.layout.activity_alert_box, null);
		  dialogbuilder.setView(dialogview);
		  dialogbuilder.setTitle("Income categories");
		  EditText ed1=(EditText)dialogview.findViewById(R.id.newed);
		  Button b1=(Button)dialogview.findViewById(R.id.newcategory);
		  AlertDialog b = dialogbuilder.create();
		  b.show();
	  }
	public void addspinner()
		{
	 //add spinner
	 sp_add_income_category=(Spinner)findViewById(R.id.Tab_sp_add_income_category);
	 ArrayAdapter<CharSequence> ad=ArrayAdapter.createFromResource(this,R.array.sp_add_income_category,android.R.layout.simple_spinner_dropdown_item);
		
		
		ad.setDropDownViewResource(android.R.layout.simple_spinner_item);
		sp_add_income_category.setAdapter(ad);
			
		
			sp_add_income_category.setOnItemSelectedListener(new OnItemSelectedListener() 
			{
			@Override
			public void onItemSelected(AdapterView<?> parent, View arg1,
					int pos, long arg3)
			{
				 s=(String)parent.getItemAtPosition(pos);		
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0)
			{}
			});

}

	private void timedateonbtn()
		{
		Calendar cal=Calendar.getInstance();
		// time
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm");
		String sdftime = sdf.format(cal.getTime());
		btn_tab_in_time.setText(sdftime);
		//date
		String date = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
		btn_tab_in_date.setText(date);
		}

	public void btn_showdate_click(View v)
	{
	 cal=Calendar.getInstance();
	 year=cal.get(Calendar.YEAR);
	 month=cal.get(Calendar.MONTH);
	 day=cal.get(Calendar.DAY_OF_MONTH);
	 showDialog(0);
	}
	
	

			protected Dialog onCreateDialog(int id)
			{
			return new DatePickerDialog(this,datepickerlitener,year,month,day);
			}
			private DatePickerDialog.OnDateSetListener datepickerlitener = new DatePickerDialog.OnDateSetListener()
			{
			@Override
			public void onDateSet(DatePicker view, int selectedday, int selectedmonth, int selectedyear)
			{
			btn_tab_in_date.setText(selectedday + " / " + (selectedmonth+1) + "/" +selectedyear);	
			}
			};
	
}
