package com.example.expensemanager2;



import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActionBar.LayoutParams;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class AddIncomes extends Activity {
	private Calendar cal;
	private int day;
	private int month;
	private int year;
	SQLiteDatabase db;
	ActionBar actionbar;
	TextView tv,tv_incomes;
	
	Button b1,btn_in_cur_time,btn_in_cur_date;
	Spinner sp_add_income_category;
	String spdescription,ss, in_amt;
	EditText ed_add_incomes_amt,ed_add_income_description;
	android.widget.RelativeLayout.LayoutParams layoutparams;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_incomes);
		ActionBarTitleGravity();
		
		ed_add_incomes_amt=(EditText)findViewById(R.id.ed_add_incomes_amt);
		ed_add_income_description=(EditText)findViewById(R.id.ed_add_income_description);
		btn_in_cur_time=(Button)findViewById(R.id.btn_in_cur_time);
		 btn_in_cur_date=(Button)findViewById(R.id.btn_in_cur_date);
		 timedateonbtn();
		 getActionBar().setHomeButtonEnabled(true);
		 
		 getActionBar().setDisplayHomeAsUpEnabled(true);
		 //add spinner
		 sp_add_income_category=(Spinner)findViewById(R.id.sp_add_income_category);
		 ArrayAdapter<CharSequence> ad=ArrayAdapter.createFromResource(this,R.array.sp_add_income_category,android.R.layout.simple_spinner_dropdown_item);
			
			
			ad.setDropDownViewResource(android.R.layout.simple_spinner_item);
			sp_add_income_category.setAdapter(ad);
			sp_add_income_category.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> parent, View arg1,
						int pos, long arg3)
				{
					spdescription=(String)parent.getItemAtPosition(pos);
					
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0)
				{
					// TODO Auto-generated method stub
					
				}
			});
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.add_incomes, menu);
		return true;
	}
	
	 private void ActionBarTitleGravity() 
	    {	
	
		  
		  actionbar = getActionBar();
		  actionbar.setHomeButtonEnabled(true);
		  actionbar.setDisplayHomeAsUpEnabled(true);
		  actionbar.setIcon(getResources().getDrawable(R.drawable.addincome));
		  actionbar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#089de3")));
		  //for textview in action bar
		  tv=new TextView(getApplicationContext());
		  layoutparams=new RelativeLayout.LayoutParams(layoutparams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);
		  tv.setLayoutParams(layoutparams);
		  tv.setText("Add Incomes");
		  tv.setTextColor(Color.parseColor("#FFFFFF"));
		  tv.setGravity(Gravity.CENTER);
		  tv.setTextSize(20);
		  actionbar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM | ActionBar.DISPLAY_SHOW_HOME);
		  actionbar.setCustomView(tv);	
		  //for button in action bar
		  b1=new Button(getApplicationContext());
		  b1.setLayoutParams(layoutparams);
		}
	 @Override
		public boolean onOptionsItemSelected(MenuItem item)
		{
			switch (item.getItemId())
			{
					case android.R.id.home:
						this.finish();
						break;

			default:
				return super.onOptionsItemSelected(item);
			}
			return true;
			
		}

	 public void addcategory(View v)
	  {
		  AlertDialog.Builder	dialogbuilder =  new AlertDialog.Builder(this);
		  LayoutInflater inflater=this.getLayoutInflater();
		  final View dialogview=inflater.inflate(R.layout.activity_alert_box, null);
		  dialogbuilder.setView(dialogview);
		 
		  dialogbuilder.setTitle("Income categories");
		  final EditText ed1=(EditText)dialogview.findViewById(R.id.newed);
		  List<String> planets = new ArrayList<String>(Arrays.asList(getResources().getStringArray(R.array.sp_add_income_category)));
		  final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,planets);
		  sp_add_income_category.setAdapter(adapter);
		  Button b1=(Button)dialogview.findViewById(R.id.newcategory);
		  final AlertDialog b = dialogbuilder.create();
		  b.show();
		  b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				
				
				String textholder = "" + ed1.getText().toString();
				adapter.add(textholder);
				b.dismiss();
					Toast.makeText(getApplicationContext(), "New Category Successfully Inserted", Toast.LENGTH_LONG).show();
			
				
			}
		});
	  }
	 
	 private void timedateonbtn()
	  	{
		 Calendar cal=Calendar.getInstance();
	  		// time
	  		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm");
	  		String sdftime = sdf.format(cal.getTime());
	  		btn_in_cur_time.setText(sdftime);
	  		//date
	  		String date = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
	  		btn_in_cur_date.setText(date);
	  	}
	 public void btn_showdate_click(View v)
	 {
		 cal=Calendar.getInstance();
		 year=cal.get(Calendar.YEAR);
		 month=cal.get(Calendar.MONTH);
		 day=cal.get(Calendar.DAY_OF_MONTH);
		 showDialog(0);
	 }
	 protected Dialog onCreateDialog(int id)
	 {
		return new DatePickerDialog(this,datepickerlitener,year,month,day);
				
	 }
	 private DatePickerDialog.OnDateSetListener datepickerlitener = new DatePickerDialog.OnDateSetListener()
	 {
		
		@Override
		public void onDateSet(DatePicker view, int selectedday, int selectedmonth, int selectedyear)
		{
		
		btn_in_cur_date.setText(selectedday + " / " + (selectedmonth+1) + "/" +selectedyear);	
		}
	};
	public void btnsave(View v) 
	{
		if(ed_add_incomes_amt.getText().toString().equals(""))
		{
			ed_add_incomes_amt.setError("Enter Amount");
		}
		else if(ed_add_income_description.getText().toString().equals(""))
		{
			ed_add_income_description.setError("Enter Description");
		}
		else
		{
		db=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.CREATE_IF_NECESSARY,null);
		String createtable = "create table if not exists incomes(in_id integer primary key autoincrement,in_amount decimal,in_type text,in_date text,in_time text,in_description text)";
		db.setLocale(Locale.getDefault());
		db.execSQL(createtable);
		String sql="insert into incomes(in_amount,in_type,in_date,in_time,in_description)values('"+ed_add_incomes_amt.getText().toString()+"','"+spdescription+"','"+btn_in_cur_date.getText().toString()+"','"+btn_in_cur_time.getText().toString()+"','"+ed_add_income_description.getText().toString()+"')";
		db.setLocale(Locale.getDefault());
		db.execSQL(sql);
		Toast.makeText(this, "Income Succesfully Inserted", Toast.LENGTH_LONG).show();
	SQLiteDatabase	db2=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE,null);
		Cursor c=db2.rawQuery("select sum(in_amount) from incomes", null);
		if(c.moveToNext())
		{
		 
		 in_amt=c.getString(0).toString();
		c.close();
		//in_amt=c.getString(0).toString();
		//tv_incomes.setText(in_amt);
		 //c.close();
		//}
	

	new AlertDialog.Builder(this)
	.setMessage(in_amt)
	.setTitle("Your Total Income Is")
	
	.setPositiveButton("OK",new DialogInterface.OnClickListener()
	{
		
		@Override
		public void onClick(DialogInterface arg0, int arg1) 
		{
			// TODO Auto-generated method stub
			
		}
	}).show();
	
		
	}
	}
	}
}
		



