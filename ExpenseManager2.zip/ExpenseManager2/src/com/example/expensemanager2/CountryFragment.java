package com.example.expensemanager2;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class CountryFragment extends Fragment 
{
@Override
public View onCreateView(LayoutInflater inflater,ViewGroup container,Bundle savedinstanceState)
{
	
	int position=getArguments().getInt("position");
	String[] cuntries = getResources().getStringArray(R.array.sp_add_expenses_category);
	View v = inflater.inflate(R.layout.activity_alert_box, container,false);
	TextView tv=(TextView)v.findViewById(R.id.textView1);
	tv.setText(cuntries[position]);
	return v;
	
}
}
