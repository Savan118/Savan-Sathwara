package com.example.expensemanager2;



import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.app.TabActivity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TextView;

public class Reminder extends TabActivity implements OnTabChangeListener {
	ActionBar actionbar;
	TextView tv;
	Button b1;
	Spinner sp_add_income_category;
	String s;
	android.widget.RelativeLayout.LayoutParams layoutparams;
	TabHost th;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_reminder);
		
		ActionBarTitleGravity();
		 getActionBar().setHomeButtonEnabled(true);
		 getActionBar().setDisplayHomeAsUpEnabled(true);
		
		 th=getTabHost();
		 th.setOnTabChangedListener(this);
			TabHost.TabSpec sp;
			Intent i;
			i=new Intent().setClass(this,Tab_Expense.class);
			sp=th.newTabSpec("Expenses").setIndicator("Expenses").setContent(i);
			th.addTab(sp);
			i=new Intent().setClass(this,Tab_Income.class);
			sp=th.newTabSpec("Incomes").setIndicator("Incomes").setContent(i);
			th.addTab(sp);
			th.getTabWidget().setCurrentTab(1);
		
			
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.reminder, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
				case android.R.id.home:
					this.finish();
					break;

		default:
			return super.onOptionsItemSelected(item);
		}
		return true;
		
	}
	private void ActionBarTitleGravity() 
    { 	
	actionbar = getActionBar();
	actionbar.setIcon(getResources().getDrawable(R.drawable.addincome));
	actionbar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#089de3")));
	//for textview in action bar
	tv=new TextView(getApplicationContext());
	layoutparams=new RelativeLayout.LayoutParams(layoutparams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);
	tv.setLayoutParams(layoutparams);
	tv.setText("Reminder");
	tv.setTextColor(Color.parseColor("#FFFFFF"));
	tv.setGravity(Gravity.CENTER);
	tv.setTextSize(20);
	actionbar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM | actionbar.DISPLAY_SHOW_HOME);
	actionbar.setCustomView(tv);	
	//for button in action bar
	b1=new Button(getApplicationContext());
	b1.setLayoutParams(layoutparams);
    }

	@Override
	public void onTabChanged(String arg0) {
		// TODO Auto-generated method stub
		
	}
	


}
