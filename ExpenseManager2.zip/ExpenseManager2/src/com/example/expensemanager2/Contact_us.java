package com.example.expensemanager2;

import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.Menu;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class Contact_us extends Activity {
	android.widget.RelativeLayout.LayoutParams layoutparams;
	private DrawerLayout mdrawerlayout;
	private ListView mdrawerlist;
	private ActionBarDrawerToggle mdrawertoggle;
	ActionBar actionbar;
	TextView tv;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_contact_us);
		ActionBarTitleGravity();
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.contact_us, menu);
		return true;
	}
	private void ActionBarTitleGravity() 
    {
    	
	actionbar = getActionBar();
	actionbar.setIcon(getResources().getDrawable(R.drawable.ic_drawer));
//	actionbar.setCustomView(R.layout.btn);
	//Button btnn=(Button)actionbar.getCustomView().findViewById(R.id.btn);
	
	actionbar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#089de3")));
	tv=new TextView(getApplicationContext());
	//b1=new Button(getApplicationContext());
	
	layoutparams=new RelativeLayout.LayoutParams(layoutparams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);
	tv.setLayoutParams(layoutparams);
	
	tv.setText("Contact us");
	tv.setTextColor(Color.parseColor("#FFFFFF"));
	tv.setGravity(Gravity.CENTER);
	
	tv.setTextSize(20);
	actionbar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM | actionbar.DISPLAY_SHOW_HOME);
	actionbar.setCustomView(tv);	
	}


}
