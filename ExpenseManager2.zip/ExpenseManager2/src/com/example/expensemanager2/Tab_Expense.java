package com.example.expensemanager2;

import java.util.Calendar;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

public class Tab_Expense extends Activity 
{
	EditText editText3;
	Button btn_tab_ex_cur_date,button3;
	private ScheduleClient scheduleClient;
	TimePickerDialog td;
	int h,m;
	int year2,month2,day2;
	private String msg;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tab__expense);
		//edittext casting
		editText3=(EditText)findViewById(R.id.editText3);
		//button casting
		btn_tab_ex_cur_date=(Button)findViewById(R.id.btn_tab_ex_cur_date);
		button3=(Button)findViewById(R.id.button3);
		
		scheduleClient = new ScheduleClient(this);       
        scheduleClient.doBindService();
        showTimePicker();
 
	}
	public void showTimePicker()
    {
    	td=new TimePickerDialog(this, new pickTime(), h, m, false);
    	td.setTitle("Select Time To Set Notification...");
    	td.show();	
    }
	 public class pickTime implements OnTimeSetListener
	    {
			@Override
			public void onTimeSet(TimePicker arg0, int arg1, int arg2) 
			{
				h = arg1;
				m = arg2;
			}
	    }
    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.tab__expense, menu);
		return true;
	}
	 
	public void addexpensecategory(View v)
		{
		  AlertDialog.Builder	dialogbuilder =  new AlertDialog.Builder(this);
		  LayoutInflater inflater=this.getLayoutInflater();
		  final View dialogview=inflater.inflate(R.layout.activity_alert_box, null);
		  dialogbuilder.setView(dialogview);
		  dialogbuilder.setTitle("Expense categories");
		  EditText ed1=(EditText)dialogview.findViewById(R.id.newed);
		  Button b1=(Button)dialogview.findViewById(R.id.newcategory);
		  AlertDialog b = dialogbuilder.create();
		  b.show();
	  }
	public void setdateclick(View v)
	{
		 Calendar cal=Calendar.getInstance();
		 year2=cal.get(Calendar.YEAR);
		 month2=cal.get(Calendar.MONTH);
		 day2=cal.get(Calendar.DAY_OF_MONTH);
		 showDialog(0);	
	}
	public void savereminderclick(View v)
	{
		Calendar c = Calendar.getInstance();
        c.set(year2, month2, day2);
        c.set(Calendar.HOUR_OF_DAY, h);
        c.set(Calendar.MINUTE, m);
        c.set(Calendar.SECOND, 0);
        msg=editText3.getText().toString();
        scheduleClient.setAlarmForNotification(c,msg);
        Toast.makeText(this, "Notification set for: "+ day2 +"/"+ (month2+1) +"/"+ year2, Toast.LENGTH_SHORT).show();
        
	}
	@Override
    protected void onStop()
    {
        if(scheduleClient != null)
            scheduleClient.doUnbindService();
        super.onStop();
    }
	protected Dialog onCreateDialog(int id)
	{
		return new DatePickerDialog(this,datepickerlitener,year2,month2,day2);
				
	}
	private DatePickerDialog.OnDateSetListener datepickerlitener = new DatePickerDialog.OnDateSetListener()
	{
		
		@Override
		public void onDateSet(DatePicker view, int selectedday, int selectedmonth, int selectedyear)
		{
		
		btn_tab_ex_cur_date.setText(selectedday + " / " + (selectedmonth+1) + "/" +selectedyear);	
		}
	};
  
	
	
}
