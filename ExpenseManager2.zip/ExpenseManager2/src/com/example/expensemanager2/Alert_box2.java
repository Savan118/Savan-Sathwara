package com.example.expensemanager2;

import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.Menu;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class Alert_box2 extends Activity {
	ActionBar actionbar;
	TextView tv;
	Button btnaddincomes,b1;
	android.widget.RelativeLayout.LayoutParams layoutparams;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_alert_box2);
		getActionBar().setDisplayHomeAsUpEnabled(true);
	      getActionBar().setHomeButtonEnabled(true);
	      ActionBarTitleGravity();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.alert_box2, menu);
		return true;
	}
	
	
	private void ActionBarTitleGravity() 
	    {
	    	
		actionbar = getActionBar();
		actionbar.setIcon(getResources().getDrawable(R.drawable.addincome));
	//	actionbar.setCustomView(R.layout.btn);
		//Button btnn=(Button)actionbar.getCustomView().findViewById(R.id.btn);
		
		actionbar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#089de3")));
		tv=new TextView(getApplicationContext());
		//b1=new Button(getApplicationContext());
		
		layoutparams=new RelativeLayout.LayoutParams(layoutparams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);
		tv.setLayoutParams(layoutparams);
		
		tv.setText("Expense Manager");
		tv.setTextColor(Color.parseColor("#FFFFFF"));
		tv.setGravity(Gravity.CENTER);
		
		tv.setTextSize(20);
		actionbar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM | actionbar.DISPLAY_SHOW_HOME);
		actionbar.setCustomView(tv);	
		}

}
