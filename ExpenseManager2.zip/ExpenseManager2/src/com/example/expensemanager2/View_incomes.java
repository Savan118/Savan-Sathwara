package com.example.expensemanager2;

import java.util.ArrayList;

import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.content.ClipData.Item;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class View_incomes extends Activity {
	android.widget.RelativeLayout.LayoutParams layoutparams;
	private DrawerLayout mdrawerlayout;
	private ListView mdrawerlist;
	private ActionBarDrawerToggle mdrawertoggle;
	ActionBar actionbar;
	TextView tv;
	ListView lv1;
	EditText edgetdata;
	Button btn1;
	Spinner sp_View_incomes;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_incomes);
		ActionBarTitleGravity();
		sp_View_incomes=(Spinner)findViewById(R.id.sp_View_incomes);
		ArrayAdapter<CharSequence> ad=ArrayAdapter.createFromResource(this,R.array.sp_search,android.R.layout.simple_spinner_dropdown_item);
		ad.setDropDownViewResource(android.R.layout.simple_spinner_item);
		sp_View_incomes.setAdapter(ad);
		sp_View_incomes.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int pos, long arg3)
			{
				switch (pos) {
				case 1:
					
					searchdb();
					break;
				case 2:
					if(edgetdata.getText().toString().equals(""))
					{
						edgetdata.setError("Enter Type");
						
					}
					else
					{
					searchdb2();
					edgetdata.setText("");
					}
					break;
				case 3:
					if(edgetdata.getText().toString().equals(""))
					{
						edgetdata.setError("Enter Amount");
						
					}
					else
					{
					searchdb3();
					edgetdata.setText("");
					}
					break;
				case 4:
					if(edgetdata.getText().toString().equals(""))
					{
						edgetdata.setError("Enter Date");
						
					}
					else
					{
					searchdb4();
					edgetdata.setText("");
					}
					break;
				case 5:
					if(edgetdata.getText().toString().equals(""))
					{
						edgetdata.setError("Enter Time");
						
					}
					else
					{
					searchdb5();
					edgetdata.setText("");
					}
					break;

				default:
					break;
				}
					
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		lv1=(ListView)findViewById(R.id.listView1);
		edgetdata=(EditText)findViewById(R.id.ed_value);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.view_incomes, menu);
		return true;
	}
	private void ActionBarTitleGravity() 
	    {
	    	
		actionbar = getActionBar();
		
		actionbar.setIcon(getResources().getDrawable(R.drawable.ic_drawer));
	//	actionbar.setCustomView(R.layout.btn);
		//Button btnn=(Button)actionbar.getCustomView().findViewById(R.id.btn);
		
		actionbar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#089de3")));
		tv=new TextView(getApplicationContext());
		//b1=new Button(getApplicationContext());
		
		layoutparams=new RelativeLayout.LayoutParams(layoutparams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);
		tv.setLayoutParams(layoutparams);
		
		tv.setText("Incomes");
		tv.setTextColor(Color.parseColor("#FFFFFF"));
		tv.setGravity(Gravity.CENTER);
		
		tv.setTextSize(20);
		actionbar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM | actionbar.DISPLAY_SHOW_HOME);
		actionbar.setCustomView(tv);	
		}
public void searchdb()
{
	
	SQLiteDatabase db=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE, null);
	 String sql="select in_amount,in_type,in_date from incomes";
	Cursor c=db.rawQuery(sql, null);
	ArrayList<String> list=new ArrayList<String>();
	list.add(" Amount "+" Type "+" Date ");
	int cnt=c.getCount();
	if(cnt>0)
	{
		while(c.moveToNext())
		{
		list.add(c.getString(0)+ "  | "+c.getString(1)+"  | "+c.getString(2));
		}
	}
	else
	{
	Toast.makeText(this, "No Records Found ...",Toast.LENGTH_LONG).show();
	}
	
	ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.select_dialog_item, list);
	lv1.setAdapter(adapter);
	c.close();
}
public void searchdb2()
{
	
	SQLiteDatabase db=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE, null);
	 String sql="select in_amount,in_type,in_description from incomes where in_type='"+edgetdata.getText().toString()+"'";
	Cursor c=db.rawQuery(sql, null);
	ArrayList<String> list=new ArrayList<String>();
	list.add(" Type "+" Amount "+" Description ");
	int cnt=c.getCount();
	if(cnt>0)
	{
		while(c.moveToNext())
		{
		list.add(c.getString(1)+ "   | "+c.getString(0)+" | "+c.getString(2));
		}
	}
	else
	{
	Toast.makeText(this, "No Records Found ...",Toast.LENGTH_LONG).show();
	}
	
	ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.select_dialog_item, list);
	lv1.setAdapter(adapter);
	c.close();
}
public void searchdb3()
{
	
	SQLiteDatabase db=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE, null);
	 String sql="select in_amount,in_date,in_time from incomes where in_amount='"+edgetdata.getText().toString()+"'";
	Cursor c=db.rawQuery(sql, null);
	ArrayList<String> list=new ArrayList<String>();
	list.add(" Amount "+" Date "+" Time ");
	int cnt=c.getCount();
	if(cnt>0)
	{
		while(c.moveToNext())
		{
		list.add(c.getString(0)+ "   | "+c.getString(1)+" | "+c.getString(2));
		}
	}
	else
	{
	Toast.makeText(this, "No Records Found ...",Toast.LENGTH_LONG).show();
	}
	
	ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.select_dialog_item, list);
	lv1.setAdapter(adapter);
	c.close();
}
public void searchdb4()
{
	
	SQLiteDatabase db=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE, null);
	 String sql="select in_date,in_time,in_amount from incomes where in_date='"+edgetdata.getText().toString()+"'";
	Cursor c=db.rawQuery(sql, null);
	ArrayList<String> list=new ArrayList<String>();
	list.add(" Date "+" Time "+" Amount ");
	int cnt=c.getCount();
	if(cnt>0)
	{
		while(c.moveToNext())
		{
		list.add(c.getString(0)+ "   | "+c.getString(1)+" | "+c.getString(2));
		}
	}
	else
	{
	Toast.makeText(this, "No Records Found ...",Toast.LENGTH_LONG).show();
	}
	
	ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.select_dialog_item, list);
	lv1.setAdapter(adapter);
	c.close();
}
public void searchdb5()
{
	
	SQLiteDatabase db=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE, null);
	 String sql="select in_time,in_date,in_amount from income swhere in_time='"+edgetdata.getText().toString()+"'";
	Cursor c=db.rawQuery(sql, null);
	ArrayList<String> list=new ArrayList<String>();
	list.add(" Time "+" Date "+" Amount ");
	int cnt=c.getCount();
	if(cnt>0)
	{
		while(c.moveToNext())
		{
		list.add(c.getString(0)+ "   | "+c.getString(1)+" | "+c.getString(2));
		}
	}
	else
	{
	Toast.makeText(this, "No Records Found ...",Toast.LENGTH_LONG).show();
	}
	
	ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.select_dialog_item, list);
	lv1.setAdapter(adapter);
	c.close();
}
}
