package com.example.expensemanager2;

import java.util.ArrayList;

import android.R;
import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.app.ListActivity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class ViewExpenses extends ListActivity {
	android.widget.RelativeLayout.LayoutParams layoutparams;
	private DrawerLayout mdrawerlayout;
	private ListView mdrawerlist;
	private ActionBarDrawerToggle mdrawertoggle;
	ActionBar actionbar;
	TextView tv,selection;
	ListView lv2;
	EditText edgetdata;
	Button btn1;
	Spinner sp_View_incomes;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_expenses);
		ActionBarTitleGravity();
		edgetdata=(EditText)findViewById(R.id.ed_value_ex);
		sp_View_incomes=(Spinner)findViewById(R.id.sp_View_incomes_ex);
		lv2=(ListView)findViewById(R.id.listView2ex);
		ArrayAdapter<CharSequence> ad=ArrayAdapter.createFromResource(this,R.array.sp_search2,android.R.layout.simple_spinner_dropdown_item);
		ad.setDropDownViewResource(android.R.layout.simple_spinner_item);
		sp_View_incomes.setAdapter(ad);
		sp_View_incomes.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int pos, long arg3)
			{
				switch (pos) {
				case 1:
					
					searchdb();
					break;
				case 2:
					if(edgetdata.getText().toString().equals(""))
					{
						edgetdata.setError("Enter Type");
						
					}
					else
					{
					searchdb2();
					edgetdata.setText("");
					}
					break;
				case 3:
					if(edgetdata.getText().toString().equals(""))
					{
						edgetdata.setError("Enter Amount");
						
					}
					else
					{
					searchdb3();
					edgetdata.setText("");
					}
					break;
				case 4:
					if(edgetdata.getText().toString().equals(""))
					{
						edgetdata.setError("Enter Date");
						
					}
					else
					{
					searchdb4();
					edgetdata.setText("");
					}
					break;
				case 5:
					if(edgetdata.getText().toString().equals(""))
					{
						edgetdata.setError("Enter Time");
						
					}
					else
					{
					searchdb5();
					edgetdata.setText("");
					}
					break;

				default:
					break;
				}
					
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.view_expenses, menu);
		return true;
	}
	
	private void ActionBarTitleGravity() 
    {
    	
	actionbar = getActionBar();
	actionbar.setIcon(getResources().getDrawable(R.drawable.ic_drawer));
//	actionbar.setCustomView(R.layout.btn);
	//Button btnn=(Button)actionbar.getCustomView().findViewById(R.id.btn);
	
	actionbar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#089de3")));
	tv=new TextView(getApplicationContext());
	//b1=new Button(getApplicationContext());
	
	layoutparams=new RelativeLayout.LayoutParams(layoutparams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);
	tv.setLayoutParams(layoutparams);
	
	tv.setText("Expenses");
	tv.setTextColor(Color.parseColor("#FFFFFF"));
	tv.setGravity(Gravity.CENTER);
	
	tv.setTextSize(20);
	actionbar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM | actionbar.DISPLAY_SHOW_HOME);
	actionbar.setCustomView(tv);	
	}

	public void searchdb()
	{
		
		SQLiteDatabase db=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE, null);
		 String sql="select ex_amount,ex_type,ex_date from expenses";
		Cursor c=db.rawQuery(sql, null);
		ArrayList<String> list2=new ArrayList<String>();
		list2.add(" Amount "+" Type "+" Date ");
		int cnt=c.getCount();
		if(cnt>0)
		{
			while(c.moveToNext())
			{
			list2.add(c.getString(0)+ "  | "+c.getString(1)+"  | "+c.getString(2));
			}
		}
		else
		{
		Toast.makeText(this, "No Records Found ...",Toast.LENGTH_LONG).show();
		}
		
		ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,, list2);
		lv2.setAdapter(adapter);
		c.close();
	}
	public void searchdb2()
	{
		
		SQLiteDatabase db=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE, null);
		 String sql="select ex_amount,ex_type,ex_description from expenses where ex_type='"+edgetdata.getText().toString()+"'";
		Cursor c=db.rawQuery(sql, null);
		ArrayList<String> list=new ArrayList<String>();
		list.add(" Type "+" Amount "+" Description ");
		int cnt=c.getCount();
		if(cnt>0)
		{
			while(c.moveToNext())
			{
			list.add(c.getString(1)+ "   | "+c.getString(0)+" | "+c.getString(2));
			}
		}
		else
		{
		Toast.makeText(this, "No Records Found ...",Toast.LENGTH_LONG).show();
		}
		
		ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.select_dialog_item, list);
		lv2.setAdapter(adapter);
		c.close();
	}
	public void searchdb3()
	{
		
		SQLiteDatabase db=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE, null);
		 String sql="select ex_amount,ex_date,ex_time from expenses where ex_amount='"+edgetdata.getText().toString()+"'";
		Cursor c=db.rawQuery(sql, null);
		ArrayList<String> list=new ArrayList<String>();
		list.add(" Amount "+" Date "+" Time ");
		int cnt=c.getCount();
		if(cnt>0)
		{
			while(c.moveToNext())
			{
			list.add(c.getString(0)+ "   | "+c.getString(1)+" | "+c.getString(2));
			}
		}
		else
		{
		Toast.makeText(this, "No Records Found ...",Toast.LENGTH_LONG).show();
		}
		
		ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.select_dialog_item, list);
		lv2.setAdapter(adapter);
		c.close();
	}
	public void searchdb4()
	{
		
		SQLiteDatabase db=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE, null);
		 String sql="select ex_date,ex_time,ex_amount from expenses where ex_date='"+edgetdata.getText().toString()+"'";
		Cursor c=db.rawQuery(sql, null);
		ArrayList<String> list=new ArrayList<String>();
		list.add(" Date "+" Time "+" Amount ");
		int cnt=c.getCount();
		if(cnt>0)
		{
			while(c.moveToNext())
			{
			list.add(c.getString(0)+ "   | "+c.getString(1)+" | "+c.getString(2));
			}
		}
		else
		{
		Toast.makeText(this, "No Records Found ...",Toast.LENGTH_LONG).show();
		}
		
		ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.select_dialog_item, list);
		lv2.setAdapter(adapter);
		c.close();
	}
	public void searchdb5()
	{
		
		SQLiteDatabase db=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE, null);
		 String sql="select ex_time,ex_date,ex_amount from expenses swhere ex_time='"+edgetdata.getText().toString()+"'";
		Cursor c=db.rawQuery(sql, null);
		ArrayList<String> list=new ArrayList<String>();
		list.add(" Time "+" Date "+" Amount ");
		int cnt=c.getCount();
		if(cnt>0)
		{
			while(c.moveToNext())
			{
			list.add(c.getString(0)+ "   | "+c.getString(1)+" | "+c.getString(2));
			}
		}
		else
		{
		Toast.makeText(this, "No Records Found ...",Toast.LENGTH_LONG).show();
		}
		
		ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.select_dialog_item, list);
		lv2.setAdapter(adapter);
		c.close();
	}
}
