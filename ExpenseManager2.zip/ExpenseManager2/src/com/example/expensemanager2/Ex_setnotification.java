package com.example.expensemanager2;

import java.util.Calendar;



import android.os.Bundle;
import android.app.Activity;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.view.Menu;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

public class Ex_setnotification extends Activity {
	private DatePicker picker;
	TimePickerDialog td;
	EditText ed1;
	int h,m;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ex_setnotification);
		picker=(DatePicker)findViewById(R.id.datePickernew);
		ed1=(EditText)findViewById(R.id.editText1);
		showTimePicker();
	}
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.ex_setnotification, menu);
		return true;
	}

	public void onclick(View v)
	{
		  int day = picker.getDayOfMonth();
	        int month = picker.getMonth();
	        int year = picker.getYear();
	        // Create a new calendar set to the date chosen
	        // we set the time to midnight (i.e. the first minute of that day)
	        Calendar c = Calendar.getInstance();
	        c.set(year, month, day);
	        c.set(Calendar.HOUR_OF_DAY,h);
	        c.set(Calendar.MINUTE,m);
	        c.set(Calendar.SECOND,0);	
	      
	}
	 public void showTimePicker()
	    {
	    	td=new TimePickerDialog(this, new pickTime(), h, m, false);
	    	td.setTitle("Select Time To Set Notification...");
	    	td.show();
	    	
	    }
	     
	    public class pickTime implements OnTimeSetListener
	    {

			@Override
			public void onTimeSet(TimePicker arg0, int arg1, int arg2) {
				// TODO Auto-generated method stub
				h = arg1;
				m = arg2;
			}
	    
	    }
}
