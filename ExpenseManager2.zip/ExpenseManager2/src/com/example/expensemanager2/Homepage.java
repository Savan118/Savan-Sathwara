package com.example.expensemanager2;


import java.text.BreakIterator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import android.R.integer;
import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActionBar.LayoutParams;
import android.content.Intent;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class Homepage extends Activity {
	//navigation drawer
	private String[] mplanettitles;
	SQLiteDatabase db;
	private DrawerLayout mdrawerlayout;
	private ListView mdrawerlist;
	private ActionBarDrawerToggle mdrawertoggle;
	ActionBar actionbar;
	TextView tv,showtotalincome,showexamount,showtotal;
	Button b1,btnok,btncancel,btn_addexpenses,btn_addincomes,btn_setreminder,btn_ViewReports,btnokpass,btnsavecheck,btncancelcheck;
	EditText editText1,edviewincomes,edviewexpense,edviewbalance,edenterpassword,edconfirmpassword,edenterpasswordcheck;
	String ex_amt,in_amt,pass,confirmpass,s;

	android.widget.RelativeLayout.LayoutParams layoutparams;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        ActionBarTitleGravity();
        navigationdrawer();
       
        btn_addexpenses=(Button)findViewById(R.id.btn_addexpenses);
        btn_addincomes=(Button)findViewById(R.id.btn_addincomes);
        btn_setreminder=(Button)findViewById(R.id.btn_setreminder);
        btn_ViewReports=(Button)findViewById(R.id.btn_ViewReports);
       
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.homepage, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item)
    {
    	if(mdrawertoggle.onOptionsItemSelected(item))
    	{
    		return true;	
    	}
    	return super.onOptionsItemSelected(item);
		
    	
    	
    }
    // Intent Navigation
    //add incomes
  	public void addincomes(View v)
  	{
  		
  		Intent i = new Intent(this,AddIncomes.class);
  		startActivity(i);
  		
  	}
  	
  	//add Expenses
  	public void addexpenses(View v)
  	{
  		
  		
  		Intent i = new Intent(this,AddExpenses.class);
  		startActivity(i);
  	}
  	// Set Reminder
  	public void setreminder(View v)
  	{
  		
  		
  		Intent i = new Intent(this,Reminder.class);
  		startActivity(i);
  	}
  	
  		//Set the ActionBar Title
  		
  		private void ActionBarTitleGravity() 
  	    {
  	    	
  		actionbar = getActionBar();
  		actionbar.setIcon(getResources().getDrawable(R.drawable.ic_drawer));
  	//	actionbar.setCustomView(R.layout.btn);
  		//Button btnn=(Button)actionbar.getCustomView().findViewById(R.id.btn);
  		
  		actionbar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#089de3")));
  		tv=new TextView(getApplicationContext());
  		//b1=new Button(getApplicationContext());
  		
  		layoutparams=new RelativeLayout.LayoutParams(layoutparams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);
  		tv.setLayoutParams(layoutparams);
  		
  		tv.setText("Expense Manager");
  		tv.setTextColor(Color.parseColor("#FFFFFF"));
  		tv.setGravity(Gravity.CENTER);
  		
  		tv.setTextSize(20);
  		actionbar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM | actionbar.DISPLAY_SHOW_HOME);
  		actionbar.setCustomView(tv);	
  		}
  		
  		private void navigationdrawer()
  		{
  			mplanettitles = getResources().getStringArray(R.array.countries);
  			
  			mdrawerlayout=(DrawerLayout)findViewById(R.id.drawer_layout);
  	        mdrawerlist=(ListView)findViewById(R.id.left_drawer);
  	        mdrawerlist.setAdapter(new ArrayAdapter<String>(this, R.layout.listview_items,mplanettitles));
  	       
  	        mdrawerlist.setOnItemClickListener(new OnItemClickListener() 
  	        {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) 
				{
					
				switch (position) 
				{
				case 0:
					Intent i = new Intent(Homepage.this,View_incomes.class);
					startActivity(i);
					mdrawerlayout.closeDrawers();
					break;
					
				case 1:
					Intent i2 = new Intent(Homepage.this,ViewExpenses.class);
					startActivity(i2);
					mdrawerlayout.closeDrawers();
					break;
				case 2:
					setpassword();
				mdrawerlayout.closeDrawers();
					break;
				case 3:
					Intent i5 = new Intent(Homepage.this,Contact_us.class);
					startActivity(i5);
					
				mdrawerlayout.closeDrawers();
					break;
				case 4:
				Intent i4 = new Intent(Homepage.this,Help.class);
				startActivity(i4);
				mdrawerlayout.closeDrawers();
					break;
				default:
				break;
				}
			
			
				}
			});
  	      mdrawertoggle=new ActionBarDrawerToggle(this,mdrawerlayout,R.drawable.addexpenses,R.string.hello_world,R.string.hello_world);
  	      mdrawerlayout.setDrawerListener(mdrawertoggle);
  	     
  	      getActionBar().setDisplayHomeAsUpEnabled(true);
  	      getActionBar().setHomeButtonEnabled(true);
  	    	  
  	      
  	        
  		}
  		
  	public void total()
  	{
  		 
		SQLiteDatabase db=openOrCreateDatabase("ExpenseManager.db",SQLiteDatabase.OPEN_READWRITE, null);
		 Cursor c=db.rawQuery("select sum(in_amount) from incomes", null);	
		 if(c.moveToNext())
			{
			 
			//in_amt=c.getString(0).toString();
			//showtotalincome.setText(in_amt);
			 //c.close();
			}
		 else
			{
				Toast.makeText(this, "no data", Toast.LENGTH_LONG).show();
			}
		
		//Cursor c2=db.rawQuery("select sum(ex_amount) from expenses", null);
		//if(c2.moveToNext())
		//{
			//in_exp=c2.getString(0).toString();
			//showexamount.setText(in_exp);	
		//}
		//else
		//{
			//Toast.makeText(this, "no data", Toast.LENGTH_LONG).show();
		//}
		
	}	
  	public void setpassword()
  	{
  	  AlertDialog.Builder	dialogbuilder =  new AlertDialog.Builder(this);
	  LayoutInflater inflater=this.getLayoutInflater();
	  final View dialogview=inflater.inflate(R.layout.addpassword, null);
	  dialogbuilder.setView(dialogview);
	  dialogbuilder.setTitle("Set Password");
	  edconfirmpassword=(EditText)dialogview.findViewById(R.id.edconfirmpassword);
	  edenterpassword=(EditText)dialogview.findViewById(R.id.edenterpassword);
	 
	  btnokpass=(Button)dialogview.findViewById(R.id.btnsave);
	  btncancel=(Button)dialogview.findViewById(R.id.btncancel);
	  
	  	// String pass=edconfirmpassword.getText().toString();
		// String confirmpass=edconfirmpassword.getText().toString();
	  final AlertDialog b2 = dialogbuilder.create();
	  b2.show();
	  btnokpass.setOnClickListener(new OnClickListener()
	  {
		
		@Override
		public void onClick(View v)
		{
			if(edenterpassword.getText().toString().equals("")) 
			{
				edenterpassword.setError("Enter password");
			}
			else if(edconfirmpassword.getText().toString().equals(""))
			{
				edenterpassword.setError("Confirm password");
			}
			
			else
			{
			SQLiteDatabase db=openOrCreateDatabase("ExpenseManager.db",SQLiteDatabase.CREATE_IF_NECESSARY, null);
			db.setLocale(Locale.getDefault());
			String sql="create table if not exists login(pass text)";
			db.execSQL(sql);
			db.setLocale(Locale.getDefault());
			String sql2="insert into login(pass)values('"+edenterpassword.getText().toString()+"')";
			db.execSQL(sql2);
			db.setLocale(Locale.getDefault());
			Toast.makeText(getApplicationContext(), "Password Added", Toast.LENGTH_LONG).show();
			b2.dismiss();
			}
			
		}
	});
	  btncancel.setOnClickListener(new OnClickListener()
	  {
		
		@Override
		public void onClick(View arg0) 
		{
			b2.dismiss();
			
		}
	});
	  
  	}
  	public void checkpass()
  	{
  		
  		 SQLiteDatabase db=openOrCreateDatabase("ExpenseManager", SQLiteDatabase.OPEN_READWRITE,null);
  		 db.setLocale(Locale.getDefault());
  		 Cursor c =db.rawQuery("select * from login", null);
  		 {
  			 if(c.getCount()>0)
  			 {
  				 c.moveToNext();
  				
  				Toast.makeText(getApplicationContext(), "hello" ,Toast.LENGTH_LONG).show();
  			 }
  			 else
  			 {
  				 Toast.makeText(getApplicationContext(), "not found",Toast.LENGTH_LONG).show();
  			 }
  		 }
  		 
  		  
	}
  	public void  login()
  	{
  		AlertDialog.Builder	dialogbuilder =  new AlertDialog.Builder(this);
		  LayoutInflater inflater=this.getLayoutInflater();
		  final View dialogview=inflater.inflate(R.layout.checkpassword, null);
		  dialogbuilder.setView(dialogview);
		  dialogbuilder.setTitle("Login");
		 
		edenterpasswordcheck=(EditText)dialogview.findViewById(R.id.edenterpasswordcheck);
		 
		btnsavecheck=(Button)dialogview.findViewById(R.id.btnsavecheck);
		btncancelcheck=(Button)dialogview.findViewById(R.id.btncancelcheck);	
	}
  	public void ViewBalance(View v)
  	{
  		
		
		  AlertDialog.Builder	dialogbuilder =  new AlertDialog.Builder(this);
		  LayoutInflater inflater=this.getLayoutInflater();
		  final View dialogview=inflater.inflate(R.layout.activity_view__balance, null);
		  dialogbuilder.setView(dialogview);
		  dialogbuilder.setTitle("Your Balance is");
		  edviewincomes=(EditText)dialogview.findViewById(R.id.edviewincomes);
		  edviewexpense=(EditText)dialogview.findViewById(R.id.edviewexpense);
		  edviewbalance=(EditText)dialogview.findViewById(R.id.edviewbalance);
		  btnok=(Button)dialogview.findViewById(R.id.btnok);
		 
		  SQLiteDatabase db2=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE,null);
			Cursor c2=db2.rawQuery("select sum(ex_amount) from expenses", null);
			if(c2.moveToNext())
			{
				 ex_amt=c2.getString(0).toString();
				edviewexpense.setText(ex_amt);	
				c2.close();
			}
			else
			{
				Toast.makeText(this, "not found", Toast.LENGTH_LONG).show();
			}
			 SQLiteDatabase db3=openOrCreateDatabase("ExpenseManager.db", SQLiteDatabase.OPEN_READWRITE,null);
				Cursor c3=db2.rawQuery("select sum(in_amount) from incomes", null);
				if(c3.moveToNext())
				{
					 in_amt=c3.getString(0).toString();
					edviewincomes.setText(in_amt);	
					c2.close();
				}
				else
				{
					Toast.makeText(this, "not found", Toast.LENGTH_LONG).show();
				}
				int b=0000;
				int a=0000;
				b = Integer.parseInt(ex_amt);
				
					a=Integer.parseInt(in_amt);
				int sum = a-b;
				String total=Integer.toString(sum);
				edviewbalance.setText(total);
		    	
		  final AlertDialog b2 = dialogbuilder.create();
		  b2.show();
		  btnok.setOnClickListener(new OnClickListener()
		  {
			
			@Override
			public void onClick(View arg0) 
			{
				b2.dismiss();
			}
		});
		
		 
	  }
	}


