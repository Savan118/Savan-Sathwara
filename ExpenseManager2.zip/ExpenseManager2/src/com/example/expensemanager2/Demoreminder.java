package com.example.expensemanager2;

import java.util.Calendar;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v4.widget.SlidingPaneLayout.PanelSlideListener;
import android.view.Menu;

public class Demoreminder extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_demoreminder);
		Intent i  = new Intent(this,Help.class);
		AlarmManager alarmmanager = (AlarmManager)getSystemService(ALARM_SERVICE);
		PendingIntent pendindintent = PendingIntent.getService(this, 0,i,0);
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.SECOND,0);
		cal.set(Calendar.MINUTE,0);
		cal.set(Calendar.HOUR,0);
		cal.set(Calendar.AM_PM,Calendar.AM);
		cal.add(Calendar.DAY_OF_MONTH, 1);
		alarmmanager.setRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),1000*60*60*24,pendindintent);
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.demoreminder, menu);
		return true;
	}

}
